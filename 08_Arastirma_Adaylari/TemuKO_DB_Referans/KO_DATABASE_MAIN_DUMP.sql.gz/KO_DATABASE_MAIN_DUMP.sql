--
-- PostgreSQL database dump
--

\restrict Yer8F3Modp3hzLwrPevc8OEmcZ2aRtWT3IOeCNNKpx7ScBM0bM1jomuGnALmVMk

-- Dumped from database version 14.23
-- Dumped by pg_dump version 14.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY dbo.account_login_control DROP CONSTRAINT idx_16389_pk_account_login_control;
DROP TABLE dbo.server_settings;
DROP TABLE dbo.server_clean;
DROP TABLE dbo.gm_maintenance_login;
DROP TABLE dbo.game_options;
DROP TABLE dbo.game_master_settings;
DROP TABLE dbo.beginner_settings;
DROP TABLE dbo.account_login_control;
DROP SCHEMA dbo;
--
-- Name: dbo; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA dbo;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_login_control; Type: TABLE; Schema: dbo; Owner: -
--

CREATE TABLE dbo.account_login_control (
    straccountid text NOT NULL,
    bangamemastername text NOT NULL,
    isauthority smallint NOT NULL,
    banreason text,
    bancount integer NOT NULL,
    opencount integer NOT NULL,
    updatetime timestamp without time zone
);


--
-- Name: beginner_settings; Type: TABLE; Schema: dbo; Owner: -
--

CREATE TABLE dbo.beginner_settings (
    serverno smallint,
    beginnertype smallint,
    beginnerdesc text
);


--
-- Name: game_master_settings; Type: TABLE; Schema: dbo; Owner: -
--

CREATE TABLE dbo.game_master_settings (
    straccountid text,
    strcharid text,
    sserverno smallint NOT NULL,
    smute smallint DEFAULT '0'::smallint NOT NULL,
    sunmute smallint DEFAULT '0'::smallint NOT NULL,
    sunban smallint DEFAULT '0'::smallint NOT NULL,
    sbanpermit smallint DEFAULT '0'::smallint NOT NULL,
    sallowattack smallint DEFAULT '0'::smallint NOT NULL,
    sdisabledattack smallint DEFAULT '0'::smallint NOT NULL,
    snpadd smallint DEFAULT '0'::smallint NOT NULL,
    sexpadd smallint DEFAULT '0'::smallint NOT NULL,
    smoneyadd smallint DEFAULT '0'::smallint NOT NULL,
    sloyaltychange smallint DEFAULT '0'::smallint NOT NULL,
    sexpchange smallint DEFAULT '0'::smallint NOT NULL,
    smoneychange smallint DEFAULT '0'::smallint NOT NULL,
    sgiveitem smallint DEFAULT '0'::smallint NOT NULL,
    sgiveitemself smallint DEFAULT '0'::smallint NOT NULL,
    ssummonuser smallint DEFAULT '0'::smallint NOT NULL,
    stponuser smallint DEFAULT '0'::smallint NOT NULL,
    szonechange smallint DEFAULT '0'::smallint NOT NULL,
    slocationchange smallint DEFAULT '0'::smallint NOT NULL,
    smonstersummon smallint DEFAULT '0'::smallint NOT NULL,
    snpcsummon smallint DEFAULT '0'::smallint NOT NULL,
    smonkilled smallint DEFAULT '0'::smallint NOT NULL,
    steleportalluser smallint DEFAULT '0'::smallint NOT NULL,
    sclansummon smallint DEFAULT '0'::smallint NOT NULL,
    sresetplayerranking smallint DEFAULT '0'::smallint NOT NULL,
    schangeeventroom smallint DEFAULT '0'::smallint NOT NULL,
    swaropen1 smallint DEFAULT '0'::smallint NOT NULL,
    swaropen2 smallint DEFAULT '0'::smallint NOT NULL,
    swaropen3 smallint DEFAULT '0'::smallint NOT NULL,
    swaropen4 smallint DEFAULT '0'::smallint NOT NULL,
    swaropen5 smallint DEFAULT '0'::smallint NOT NULL,
    swaropen6 smallint DEFAULT '0'::smallint NOT NULL,
    swaropen9 smallint DEFAULT '0'::smallint NOT NULL,
    swarsiegeopen smallint DEFAULT '0'::smallint NOT NULL,
    swarclose smallint DEFAULT '0'::smallint NOT NULL,
    scaptainelection smallint DEFAULT '0'::smallint NOT NULL,
    swarsiegeclose smallint DEFAULT '0'::smallint NOT NULL,
    ssendprsion smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: game_options; Type: TABLE; Schema: dbo; Owner: -
--

CREATE TABLE dbo.game_options (
    maintenancemode smallint NOT NULL,
    characterselectlogin smallint,
    openotp smallint NOT NULL,
    autoregister smallint NOT NULL,
    freelimit smallint NOT NULL,
    totaluserlimit smallint NOT NULL,
    serveripaddress text NOT NULL
);


--
-- Name: gm_maintenance_login; Type: TABLE; Schema: dbo; Owner: -
--

CREATE TABLE dbo.gm_maintenance_login (
    gmloginid text NOT NULL
);


--
-- Name: server_clean; Type: TABLE; Schema: dbo; Owner: -
--

CREATE TABLE dbo.server_clean (
    format smallint,
    server001 smallint,
    server002 smallint,
    server003 smallint,
    server004 smallint,
    server005 smallint,
    server006 smallint,
    server007 smallint,
    server008 smallint,
    server009 smallint,
    server010 smallint
);


--
-- Name: server_settings; Type: TABLE; Schema: dbo; Owner: -
--

CREATE TABLE dbo.server_settings (
    nserverno integer DEFAULT 1 NOT NULL,
    maximumlevelchange smallint DEFAULT '83'::smallint NOT NULL,
    dropnotice smallint NOT NULL,
    upgradenotice smallint NOT NULL,
    usermaxupgradecount smallint DEFAULT '0'::smallint NOT NULL,
    openquestskill smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Data for Name: account_login_control; Type: TABLE DATA; Schema: dbo; Owner: -
--

COPY dbo.account_login_control (straccountid, bangamemastername, isauthority, banreason, bancount, opencount, updatetime) FROM stdin;
11juan11             	                     	1		0	0	2023-04-23 13:51:35.48
abbb                 	                     	1		0	0	2025-06-24 09:59:07.897
almirantetarkin      	                     	1		0	0	2022-05-23 23:20:47.517
anakin               	                     	1		0	0	2022-05-24 23:53:37.98
animeflv7            	                     	1		0	0	2023-05-06 09:55:53.043
anthony1991          	                     	1		0	0	2022-05-23 02:00:39.187
anthony19991         	                     	1		0	0	2022-05-25 03:21:13.267
arsenal              	                     	1		0	0	2024-10-14 15:19:44.657
piedras              	                     	1		0	0	2022-04-29 22:26:09.607
valorum              	                     	1		0	0	2022-05-23 23:32:44.24
warriorcalatooo      	                     	1		0	0	2022-05-18 22:30:17.1
yourstrong           	                     	1		0	0	2022-05-07 15:14:42.39
yunus                	                     	1		0	0	2024-10-14 15:13:30.363
yunus280             	                     	1		0	0	2024-10-14 15:08:42.25
123                  	                     	1		0	0	2022-05-23 04:03:35.347
adamant              	                     	1		0	0	2023-04-22 20:41:49.187
bfnascualquiernick   	                     	1		0	0	2022-11-02 05:25:12.32
bladee1621           	                     	1		0	0	2023-04-22 18:46:12.37
CadeACS              	                     	1		0	0	2023-04-22 19:10:16.673
cadoeACS             	                     	1		0	0	2023-04-22 19:08:04.397
calladito            	                     	1		0	0	2022-05-24 01:06:33.25
CodeACS              	                     	1		0	0	2023-04-22 19:12:04.083
comboyapmak12        	                     	1		0	0	2023-04-22 17:16:20.083
cypher               	                     	1		0	0	2022-11-02 05:26:03.617
darkdevi22           	                     	1		0	0	2023-04-22 21:18:12.713
david009             	                     	1		0	0	2023-04-24 08:26:48.88
DeathMannn           	                     	1		0	0	2023-04-23 09:10:16.383
drivus               	                     	1		0	0	2023-05-06 09:54:05.093
drivus1              	                     	1		0	0	2023-05-06 13:44:53.617
dsadas               	                     	1		0	0	2023-04-23 14:42:19.977
dsds                 	                     	1		0	0	2022-05-26 23:07:14.02
dsdsds               	                     	1		0	0	2022-05-26 23:01:52.183
ESLYVER45            	                     	1		0	0	2023-04-27 21:59:23.74
fasdfa               	                     	1		0	0	2022-05-01 22:54:25.427
hpyoplac             	                     	1		0	0	2023-04-22 18:05:25.163
iceiceice            	                     	1		0	0	2022-12-31 23:59:32.973
jamon                	                     	1		0	0	2025-06-24 10:00:05.323
jamonada             	                     	1		0	0	2022-05-24 00:35:19.193
jejejre              	                     	1		0	0	2023-04-26 11:57:41.827
jfjsnfdlkjasdnjl     	                     	1		0	0	2025-06-15 20:52:03.923
jijijiji             	                     	1		0	0	2023-09-14 09:53:06.13
jisjijasda           	                     	1		0	0	2022-05-18 22:19:25.94
jjsdh                	                     	1		0	0	2025-06-15 20:57:44.647
jkjkjk               	                     	1		0	0	2023-09-14 09:44:33.39
juanloco             	                     	1		0	0	2025-06-19 20:41:02.977
juaz123              	                     	1		0	0	2024-06-25 09:44:51.89
juaz1234             	                     	1		0	0	2024-06-25 10:31:18
jueves123            	                     	1		0	0	2023-09-14 08:44:52.383
jujrjrjjnjnj         	                     	1		0	0	2022-05-23 23:15:28.72
jurajjanj            	                     	1		0	0	2022-05-18 22:20:18.623
jurujujaja           	                     	1		0	0	2023-04-22 14:31:59.973
karlanga01           	                     	1		0	0	2023-04-28 16:58:18.94
ldhhfjhaj            	                     	1		0	0	2022-05-01 22:58:22.48
llerena3             	                     	1		0	0	2023-03-23 06:14:42.917
locoismael           	                     	1		0	0	2023-05-02 10:50:52.993
lokillo              	                     	1		0	0	2022-05-24 22:40:54.333
loko87               	                     	1		0	0	2025-06-19 20:33:15.783
luisfelipe18         	                     	1		0	0	2022-05-19 04:34:29.68
meyergold            	                     	1		0	0	2023-04-26 10:41:11.68
meyergold1           	                     	1		0	0	2023-04-26 11:19:59.05
newelement0792       	                     	1		0	0	2023-04-24 18:20:03.467
newelement199        	                     	1		0	0	2023-04-25 09:38:29.267
newelement1991       	                     	1		0	0	2023-04-23 01:37:00.72
newelement1992       	                     	1		0	0	2023-04-23 00:36:42.183
palpatine            	                     	1		0	0	2022-05-25 20:58:26.417
PISCO                	                     	1		0	0	2023-04-23 14:04:18.953
player               	                     	1		0	0	2022-08-15 14:33:44.7
q                    	                     	1		0	0	2024-03-06 11:15:41.91
ratasucia            	                     	1		0	0	2022-05-24 00:26:35.343
ricocanwau           	                     	1		0	0	2024-10-31 21:06:14.06
sliper123            	                     	1		0	0	2022-05-23 01:55:12.223
snakemc29            	                     	1		0	0	2023-04-26 17:10:18.097
tarjin               	                     	1		0	0	2022-05-23 23:38:16.68
tarkintarkin         	                     	1		0	0	2022-05-23 23:24:29.187
temuk0               	                     	1		0	0	2022-07-25 01:40:34.683
temuko               	                     	1		0	0	2022-07-25 01:39:54.193
temuselacome         	                     	1		0	0	2023-04-23 07:17:42.563
theskywalker         	                     	1		0	0	2023-09-14 08:41:41.64
toto01               	                     	1		0	0	2023-04-30 07:38:06.82
\.


--
-- Data for Name: beginner_settings; Type: TABLE DATA; Schema: dbo; Owner: -
--

COPY dbo.beginner_settings (serverno, beginnertype, beginnerdesc) FROM stdin;
1	4	1:Ardream 2:Ronark Land Base 3:Ronark Land 0:False
\.


--
-- Data for Name: game_master_settings; Type: TABLE DATA; Schema: dbo; Owner: -
--

COPY dbo.game_master_settings (straccountid, strcharid, sserverno, smute, sunmute, sunban, sbanpermit, sallowattack, sdisabledattack, snpadd, sexpadd, smoneyadd, sloyaltychange, sexpchange, smoneychange, sgiveitem, sgiveitemself, ssummonuser, stponuser, szonechange, slocationchange, smonstersummon, snpcsummon, smonkilled, steleportalluser, sclansummon, sresetplayerranking, schangeeventroom, swaropen1, swaropen2, swaropen3, swaropen4, swaropen5, swaropen6, swaropen9, swarsiegeopen, swarclose, scaptainelection, swarsiegeclose, ssendprsion) FROM stdin;
SLIPER123            	LumiStone            	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
tester               	wwtester             	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
slowly	VANHELSING           	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
arsenal              	arsenal              	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
temu                 	TEMU                 	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
NIF                  	NIF                  	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
temu                 	TEMU                 	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
sliper123            	lumistone            	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
temu                 	mTEMU                	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
loko87               	King                 	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
temu	kTEMU                	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
temu                 	TEMU                 	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
loko87               	King                 	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
\.


--
-- Data for Name: game_options; Type: TABLE DATA; Schema: dbo; Owner: -
--

COPY dbo.game_options (maintenancemode, characterselectlogin, openotp, autoregister, freelimit, totaluserlimit, serveripaddress) FROM stdin;
0	1	0	1	300	300	127.0.0.1
\.


--
-- Data for Name: gm_maintenance_login; Type: TABLE DATA; Schema: dbo; Owner: -
--

COPY dbo.gm_maintenance_login (gmloginid) FROM stdin;
\.


--
-- Data for Name: server_clean; Type: TABLE DATA; Schema: dbo; Owner: -
--

COPY dbo.server_clean (format, server001, server002, server003, server004, server005, server006, server007, server008, server009, server010) FROM stdin;
1	1	1	0	0	0	0	0	0	0	0
\.


--
-- Data for Name: server_settings; Type: TABLE DATA; Schema: dbo; Owner: -
--

COPY dbo.server_settings (nserverno, maximumlevelchange, dropnotice, upgradenotice, usermaxupgradecount, openquestskill) FROM stdin;
1	83	1	1	99	1
\.


--
-- Name: account_login_control idx_16389_pk_account_login_control; Type: CONSTRAINT; Schema: dbo; Owner: -
--

ALTER TABLE ONLY dbo.account_login_control
    ADD CONSTRAINT idx_16389_pk_account_login_control PRIMARY KEY (straccountid);


--
-- PostgreSQL database dump complete
--

\unrestrict Yer8F3Modp3hzLwrPevc8OEmcZ2aRtWT3IOeCNNKpx7ScBM0bM1jomuGnALmVMk

